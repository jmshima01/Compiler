I used `Go` (1.22.1) for this project which is not listed on the site.
However I did make a install script like the other languages locally to 
`~/bin` and works/tested on isengard assuming the user has a `~/bin`
by running `source installGo.sh` should install go properly.

Then all thats required is to run make and the `LUTHOR` binary should be
created/compiled.

