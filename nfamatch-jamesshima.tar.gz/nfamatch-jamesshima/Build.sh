#!/bin/python3

chmod 755 NFAMATCH
